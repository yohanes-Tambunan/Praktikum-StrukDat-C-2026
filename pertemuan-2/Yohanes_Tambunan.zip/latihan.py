#jawaban 1
stock = [15, 50, 30, 25, 40]
stock.append(100)
print(stock)
stock.insert(2, 75)
print(stock)
stock.sort (reverse = True)
print(stock)
rata = 0
for x in stock:
    rata += x
rata_rata = rata / len(stock)
print(stock)
print(rata_rata)


#jawaban 2
barang = ("B001", "Laptop Gaming", 15000000)
print (barang[2])

harga_baru = list(barang)
harga_baru[2] = 14000000
x = tuple(harga_baru)
print(barang)


#jawaban 3
tim_frontend = {"HTML", "CSS", "JavaScript", "React"}
tim_backend = {"Python", "JavaScript", "SQL",
"NodeJS"}

tim_baru = tim_fronted.intersection(tim_backend)
print(set3)

for x in tim_backend
    print(x)

set3 = tim_frontend.union(tim_backend)

print(set3)
  



